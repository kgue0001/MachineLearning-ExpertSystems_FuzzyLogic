#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os  
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn import preprocessing
from sklearn.preprocessing import StandardScaler
import seaborn as sns
from sklearn.metrics import confusion_matrix
get_ipython().run_line_magic('matplotlib', 'inline import pandas as pd')


# In[2]:


train = pd.read_csv('mnist_train.csv', header = None)
print(train.shape)
train.head()


# In[3]:


test = pd.read_csv('mnist_test.csv', header = None)
print(test.shape)
test.head()


# In[5]:


sns.countplot(train.iloc[:, 0])
plt.show()


# In[6]:


X_train = train.iloc[:,1:]
y_train = train.iloc[:, 0]
X_test = test.iloc[:,1:]
y_test = test.iloc[:, 0]


# In[7]:


from sklearn import svm
from sklearn.svm import SVC
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GridSearchCV

steps = [('scaler', StandardScaler()), ('SVM', SVC(kernel='poly'))]
pipeline = Pipeline(steps)


# In[8]:


param_grid = {'C': [0.1,1],'kernel': ['rbf','poly']}


# In[9]:


grid = GridSearchCV(SVC(),param_grid,verbose=2)
grid.fit(X_train,y_train)


# In[10]:


print ("score = %3.2f" %(grid.score(X_test, y_test)))
print ("best parameters from train data: ", grid.best_params_)


# In[11]:


y_pred = grid.predict(X_test)
y_pred[100:105]


# In[12]:


print("confusion matrix: \n ", confusion_matrix(y_test, y_pred))

